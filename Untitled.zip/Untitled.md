```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv(r"C:\Users\BHARTI\Downloads\retail_sales_dataset (1).csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Transaction ID</th>
      <th>Date</th>
      <th>Customer ID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Product Category</th>
      <th>Quantity</th>
      <th>Price per Unit</th>
      <th>Total Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>11/24/2023</td>
      <td>CUST001</td>
      <td>Male</td>
      <td>34</td>
      <td>Beauty</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2/27/2023</td>
      <td>CUST002</td>
      <td>Female</td>
      <td>26</td>
      <td>Clothing</td>
      <td>2</td>
      <td>500</td>
      <td>1000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1/13/2023</td>
      <td>CUST003</td>
      <td>Male</td>
      <td>50</td>
      <td>Electronics</td>
      <td>1</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>5/21/2023</td>
      <td>CUST004</td>
      <td>Male</td>
      <td>37</td>
      <td>Clothing</td>
      <td>1</td>
      <td>500</td>
      <td>500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5/6/2023</td>
      <td>CUST005</td>
      <td>Male</td>
      <td>30</td>
      <td>Beauty</td>
      <td>2</td>
      <td>50</td>
      <td>100</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>5/16/2023</td>
      <td>CUST996</td>
      <td>Male</td>
      <td>62</td>
      <td>Clothing</td>
      <td>1</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>11/17/2023</td>
      <td>CUST997</td>
      <td>Male</td>
      <td>52</td>
      <td>Beauty</td>
      <td>3</td>
      <td>30</td>
      <td>90</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>10/29/2023</td>
      <td>CUST998</td>
      <td>Female</td>
      <td>23</td>
      <td>Beauty</td>
      <td>4</td>
      <td>25</td>
      <td>100</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>12/5/2023</td>
      <td>CUST999</td>
      <td>Female</td>
      <td>36</td>
      <td>Electronics</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>4/12/2023</td>
      <td>CUST1000</td>
      <td>Male</td>
      <td>47</td>
      <td>Electronics</td>
      <td>4</td>
      <td>30</td>
      <td>120</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
print(df.info())
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1000 entries, 0 to 999
    Data columns (total 9 columns):
     #   Column            Non-Null Count  Dtype 
    ---  ------            --------------  ----- 
     0   Transaction ID    1000 non-null   int64 
     1   Date              1000 non-null   object
     2   Customer ID       1000 non-null   object
     3   Gender            1000 non-null   object
     4   Age               1000 non-null   int64 
     5   Product Category  1000 non-null   object
     6   Quantity          1000 non-null   int64 
     7   Price per Unit    1000 non-null   int64 
     8   Total Amount      1000 non-null   int64 
    dtypes: int64(5), object(4)
    memory usage: 70.4+ KB
    None
    


```python

```


```python
print(df.head())
```

       Transaction ID        Date Customer ID  Gender  Age Product Category  \
    0               1  11/24/2023     CUST001    Male   34           Beauty   
    1               2   2/27/2023     CUST002  Female   26         Clothing   
    2               3   1/13/2023     CUST003    Male   50      Electronics   
    3               4   5/21/2023     CUST004    Male   37         Clothing   
    4               5    5/6/2023     CUST005    Male   30           Beauty   
    
       Quantity  Price per Unit  Total Amount  
    0         3              50           150  
    1         2             500          1000  
    2         1              30            30  
    3         1             500           500  
    4         2              50           100  
    


```python

```


```python
print(df.describe())
```

           Transaction ID         Age     Quantity  Price per Unit  Total Amount
    count     1000.000000  1000.00000  1000.000000     1000.000000   1000.000000
    mean       500.500000    41.39200     2.514000      179.890000    456.000000
    std        288.819436    13.68143     1.132734      189.681356    559.997632
    min          1.000000    18.00000     1.000000       25.000000     25.000000
    25%        250.750000    29.00000     1.000000       30.000000     60.000000
    50%        500.500000    42.00000     3.000000       50.000000    135.000000
    75%        750.250000    53.00000     4.000000      300.000000    900.000000
    max       1000.000000    64.00000     4.000000      500.000000   2000.000000
    


```python
df.describe(include="O")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Customer ID</th>
      <th>Gender</th>
      <th>Product Category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>345</td>
      <td>1000</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>top</th>
      <td>5/16/2023</td>
      <td>CUST1000</td>
      <td>Female</td>
      <td>Clothing</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>11</td>
      <td>1</td>
      <td>510</td>
      <td>351</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
df.isnull().sum()
```




    Transaction ID      0
    Date                0
    Customer ID         0
    Gender              0
    Age                 0
    Product Category    0
    Quantity            0
    Price per Unit      0
    Total Amount        0
    dtype: int64




```python

```


```python
# snake casing
df.columns = df.columns.str.lower()
df.columns = df.columns.str.replace(" ","_")
```


```python
df.columns
```




    Index(['transaction_id', 'date', 'customer_id', 'gender', 'age',
           'product_category', 'quantity', 'price_per_unit', 'total_amount'],
          dtype='object')




```python

```


```python
df.duplicated().sum()
```




    np.int64(0)




```python

```


```python
# change date-datatype of date column-----

df["date"] = pd.to_datetime(df["date"])
print(df.dtypes)
```

    transaction_id               int64
    date                datetime64[ns]
    customer_id                 object
    gender                      object
    age                          int64
    product_category            object
    quantity                     int64
    price_per_unit               int64
    total_amount                 int64
    dtype: object
    


```python
# create new features----

df["year"] = df["date"].dt.year
df["month"] = df["date"].dt.month
df["day"] = df["date"].dt.day
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction_id</th>
      <th>date</th>
      <th>customer_id</th>
      <th>gender</th>
      <th>age</th>
      <th>product_category</th>
      <th>quantity</th>
      <th>price_per_unit</th>
      <th>total_amount</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2023-11-24</td>
      <td>CUST001</td>
      <td>Male</td>
      <td>34</td>
      <td>Beauty</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
      <td>2023</td>
      <td>11</td>
      <td>24</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2023-02-27</td>
      <td>CUST002</td>
      <td>Female</td>
      <td>26</td>
      <td>Clothing</td>
      <td>2</td>
      <td>500</td>
      <td>1000</td>
      <td>2023</td>
      <td>2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2023-01-13</td>
      <td>CUST003</td>
      <td>Male</td>
      <td>50</td>
      <td>Electronics</td>
      <td>1</td>
      <td>30</td>
      <td>30</td>
      <td>2023</td>
      <td>1</td>
      <td>13</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2023-05-21</td>
      <td>CUST004</td>
      <td>Male</td>
      <td>37</td>
      <td>Clothing</td>
      <td>1</td>
      <td>500</td>
      <td>500</td>
      <td>2023</td>
      <td>5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2023-05-06</td>
      <td>CUST005</td>
      <td>Male</td>
      <td>30</td>
      <td>Beauty</td>
      <td>2</td>
      <td>50</td>
      <td>100</td>
      <td>2023</td>
      <td>5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>2023-05-16</td>
      <td>CUST996</td>
      <td>Male</td>
      <td>62</td>
      <td>Clothing</td>
      <td>1</td>
      <td>50</td>
      <td>50</td>
      <td>2023</td>
      <td>5</td>
      <td>16</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>2023-11-17</td>
      <td>CUST997</td>
      <td>Male</td>
      <td>52</td>
      <td>Beauty</td>
      <td>3</td>
      <td>30</td>
      <td>90</td>
      <td>2023</td>
      <td>11</td>
      <td>17</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>2023-10-29</td>
      <td>CUST998</td>
      <td>Female</td>
      <td>23</td>
      <td>Beauty</td>
      <td>4</td>
      <td>25</td>
      <td>100</td>
      <td>2023</td>
      <td>10</td>
      <td>29</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>2023-12-05</td>
      <td>CUST999</td>
      <td>Female</td>
      <td>36</td>
      <td>Electronics</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
      <td>2023</td>
      <td>12</td>
      <td>5</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>2023-04-12</td>
      <td>CUST1000</td>
      <td>Male</td>
      <td>47</td>
      <td>Electronics</td>
      <td>4</td>
      <td>30</td>
      <td>120</td>
      <td>2023</td>
      <td>4</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 12 columns</p>
</div>



# Exploratory Data Analysis (EDA)--------


### Demographic Influence on Purchasing Behavior


```python
 # Average spendig by gender------

df.groupby("gender")["total_amount"].mean()      
```




    gender
    Female    456.549020
    Male      455.428571
    Name: total_amount, dtype: float64




```python
plt.figure(figsize=(7,4))
sns.barplot(x="gender", y="total_amount", data=df)
plt.title("AVERAGE SPENDING BY GENDER")
plt.show()
```


    
![png](output_22_0.png)
    



```python
# relationship between age and spending------

plt.figure(figsize=(7,4))
sns.scatterplot(x = "age", y = "total_amount", hue = "gender", data=df)
plt.title("AGE VS SPENDING BY GENDER")
plt.show()
```


    
![png](output_23_0.png)
    



```python

```

## Sales Patterns Across Time Periods


```python
# create new column(season) from month--------

def season(month):
    if month in [12,1,2]:
        return "Winter"
    elif month in [3,4,5]:
        return "Spring"
    elif month in [6,7,8]:
        return "Summer"
    else:
        return "Autumn"
    
df["season"] = df["month"].apply(season)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction_id</th>
      <th>date</th>
      <th>customer_id</th>
      <th>gender</th>
      <th>age</th>
      <th>product_category</th>
      <th>quantity</th>
      <th>price_per_unit</th>
      <th>total_amount</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2023-11-24</td>
      <td>CUST001</td>
      <td>Male</td>
      <td>34</td>
      <td>Beauty</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
      <td>2023</td>
      <td>11</td>
      <td>24</td>
      <td>Autumn</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2023-02-27</td>
      <td>CUST002</td>
      <td>Female</td>
      <td>26</td>
      <td>Clothing</td>
      <td>2</td>
      <td>500</td>
      <td>1000</td>
      <td>2023</td>
      <td>2</td>
      <td>27</td>
      <td>Winter</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2023-01-13</td>
      <td>CUST003</td>
      <td>Male</td>
      <td>50</td>
      <td>Electronics</td>
      <td>1</td>
      <td>30</td>
      <td>30</td>
      <td>2023</td>
      <td>1</td>
      <td>13</td>
      <td>Winter</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2023-05-21</td>
      <td>CUST004</td>
      <td>Male</td>
      <td>37</td>
      <td>Clothing</td>
      <td>1</td>
      <td>500</td>
      <td>500</td>
      <td>2023</td>
      <td>5</td>
      <td>21</td>
      <td>Spring</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2023-05-06</td>
      <td>CUST005</td>
      <td>Male</td>
      <td>30</td>
      <td>Beauty</td>
      <td>2</td>
      <td>50</td>
      <td>100</td>
      <td>2023</td>
      <td>5</td>
      <td>6</td>
      <td>Spring</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>2023-05-16</td>
      <td>CUST996</td>
      <td>Male</td>
      <td>62</td>
      <td>Clothing</td>
      <td>1</td>
      <td>50</td>
      <td>50</td>
      <td>2023</td>
      <td>5</td>
      <td>16</td>
      <td>Spring</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>2023-11-17</td>
      <td>CUST997</td>
      <td>Male</td>
      <td>52</td>
      <td>Beauty</td>
      <td>3</td>
      <td>30</td>
      <td>90</td>
      <td>2023</td>
      <td>11</td>
      <td>17</td>
      <td>Autumn</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>2023-10-29</td>
      <td>CUST998</td>
      <td>Female</td>
      <td>23</td>
      <td>Beauty</td>
      <td>4</td>
      <td>25</td>
      <td>100</td>
      <td>2023</td>
      <td>10</td>
      <td>29</td>
      <td>Autumn</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>2023-12-05</td>
      <td>CUST999</td>
      <td>Female</td>
      <td>36</td>
      <td>Electronics</td>
      <td>3</td>
      <td>50</td>
      <td>150</td>
      <td>2023</td>
      <td>12</td>
      <td>5</td>
      <td>Winter</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>2023-04-12</td>
      <td>CUST1000</td>
      <td>Male</td>
      <td>47</td>
      <td>Electronics</td>
      <td>4</td>
      <td>30</td>
      <td>120</td>
      <td>2023</td>
      <td>4</td>
      <td>12</td>
      <td>Spring</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 13 columns</p>
</div>




```python
# Sales by monthly----

monthly_sales = df.groupby("month")["total_amount"].sum().reset_index()
```


```python
plt.figure(figsize=(7,4))
sns.lineplot(x="month",y="total_amount", data = monthly_sales, marker='o')
plt.title("MONTHLY SALES TREND")
plt.show()
```


    
![png](output_29_0.png)
    



```python

```

## Product Category Preferences


```python
# Product category by sales-----
plt.figure(figsize=(7,4))
sns.barplot(x="product_category",y="total_amount", data=df)
plt.title("REVENUE BY PRODUCT CATEGORY")
plt.show()
```


    
![png](output_32_0.png)
    



```python

```

## Customer Spending and Product Preferences


```python
# correlations between age, total spending, and product choices----

plt.figure(figsize=(7,4))
sns.scatterplot(x="age",y="total_amount", hue="product_category",data=df)
plt.title("CORRELATION BETWEEN AGE AND SPENDING")
plt.show()
```


    
![png](output_35_0.png)
    



```python

```

## Seasonal Shopping Trends


```python
# purchasing behavior during different seasons

plt.figure.figsize=(7,4)
sns.boxplot(x="season",y="total_amount",hue="gender",data=df)
plt.title("SPENDING DURING DIFFERENT SEASON")
plt.show()
```


    
![png](output_38_0.png)
    



```python

```

## Transaction-Based Purchasing Behavior


```python
# quantity bought per transaction on total spending-----

plt.figure.figsize=(7,4)
sns.scatterplot(x="quantity",y="total_amount",data=df)
plt.title("QUANTITY BOUGH VS TOTAL SPENDING")
plt.xlabel("QUANTITY PER TRANSITION")
plt.ylabel("TOTAL AMOUNT SPENT")
plt.show()
```


    
![png](output_41_0.png)
    



```python

```

## Product Price Distribution Insights


```python
# Price distribution----

plt.figure.figsize=(7,4)
sns.boxplot(x="product_category",y="price_per_unit",data=df)
plt.title("PRICE BY EACH PRODUCT")
plt.show()
```


    
![png](output_44_0.png)
    



```python

```


```python

```
